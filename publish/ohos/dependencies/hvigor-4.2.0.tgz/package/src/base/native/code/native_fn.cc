/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2021-2023. All rights reserved.
 *
 */

#include <uv.h>
#include <napi.h>

Napi::Value exec_uv_run(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();
  Napi::HandleScope scope(env);
  uv_run(uv_default_loop(), UV_RUN_ONCE);
  return env.Undefined();
}

static Napi::Object init(Napi::Env env, Napi::Object exports) {
  exports.Set(Napi::String::New(env, "exec_uv_run"), Napi::Function::New(env, exec_uv_run));
  return exports;
}

NODE_API_MODULE(native_fn, init)