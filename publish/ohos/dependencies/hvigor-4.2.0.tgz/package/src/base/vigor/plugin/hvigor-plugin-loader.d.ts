export declare class HvigorPluginLoader {
    private initFnQueue;
    private applyFnQueue;
    private loaderState;
    addInitAction(fn: Function): void;
    addApplyAction(fn: Function): void;
    clean(): void;
    setState(state: PluginLoaderState): void;
    getState(): string;
    loadingPlugins(): Promise<void>;
    private loadingInitQueue;
    private loadingApplyQueue;
    private executeQueue;
}
export declare enum PluginLoaderState {
    NONE = "none",
    INIT = "init",
    APPLY = "apply",
    LOADED = "loaded"
}
export declare const onPluginInit: (loader: HvigorPluginLoader) => void;
export declare const onPluginApply: (loader: HvigorPluginLoader) => void;
export declare const onPluginLoaded: (loader: HvigorPluginLoader) => void;
export declare const hvigorPluginLoader: HvigorPluginLoader;
