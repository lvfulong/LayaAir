import { TargetTaskService } from './service/target-task-service.js';
import { BaseBuildProfileTask } from './base-build-profile-task';
import { FileSet, TaskInputValue } from '@ohos/hvigor';
export declare class BuildProfileTask extends BaseBuildProfileTask {
    constructor(taskService: TargetTaskService);
    declareInputs(): Map<string, TaskInputValue>;
    /**
     * 添加增量判断，当app.json5或工程级的build-profile.json5文件发生变化时重新生成buildProfile.ets文件
     */
    declareInputFiles(): FileSet;
    declareOutputFiles(): FileSet;
    protected doTaskAction(): void;
}
