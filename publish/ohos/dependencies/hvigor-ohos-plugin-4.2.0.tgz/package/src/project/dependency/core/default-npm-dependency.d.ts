import { DependencyBuilder } from './dependency-builder.js';
import { Dependency, DependencyEnum, DependencyType } from './dependency-interface.js';
/**
 * module对应的所有的har依赖的包信息类
 *
 * @since 2022/5/7
 */
export declare class DefaultNpmDependency implements Dependency {
    private readonly _dependencyName;
    private readonly _dependencyVersion;
    private readonly _dependencyRootPath;
    private readonly _dependencies;
    private readonly _pkgJsonPath;
    private readonly _pkgJsonName;
    private readonly _mainFilePath;
    private readonly _typesFilePath;
    private readonly _dependencyType;
    private readonly _dependencyEnum;
    private readonly _pkgJsonObj;
    constructor(denpendencyBuilder: DependencyBuilder);
    getPackageJsonPath(): string;
    getPackageFilePath(): string;
    getPackageName(): string;
    getDependencyName(): string;
    getDependencyVersion(): string;
    getDependencyRootPath(): string;
    getDependencyMainFilePath(): string;
    getDependencyTypesFilePath(): string;
    getDependencyType(): DependencyType;
    getDependencyEnum(): DependencyEnum;
    getDependencies(): Partial<Record<string, string>>;
    hasNative(): boolean;
}
